export default {
    testEnvironment: "node",
    moduleFileExtensions: ["js", "ts"],
};
