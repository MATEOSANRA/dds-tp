import { EstacionesTable } from "./EstacionesTable/EstacionesTable";
import { Link } from "react-router-dom";

export const ListaEstaciones = () => {
  return (
    <div className="m-3">
      <h2 className="d-flex justify-content-between">
        Listado de Estaciones
        <div>
          <Link to="/estaciones/crear">
            <button className="btn btn-primary">
              Crear Estacion
              </button>
          </Link>
        </div>
      </h2>
      <hr />
      <EstacionesTable />
    </div>
  );
};
