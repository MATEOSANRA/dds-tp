import React, { useState } from "react";
import { useEffect } from "react";
import { get, useForm } from "react-hook-form";
import estacionesService from "../../../services/estacionesService";
import { useNavigate, useSearchParams, useLocation } from "react-router-dom"

const BARRIOS = [
  { idBarrio: 7, nombre: "CENTRO" },
  { idBarrio: 1, nombre: "CIUDAD UNIVERSITARIA" },
  { idBarrio: 2, nombre: "NUEVA CÓRDOBA" },
  { idBarrio: 19, nombre: "Nuevo Barrio" },
  { idBarrio: 20, nombre: "Nuevo Barrio" },
  { idBarrio: 21, nombre: "Nuevo Barrio" },
  { idBarrio: 4, nombre: "ZONA ESTE" },
  { idBarrio: 5, nombre: "ZONA NORTE" },
  { idBarrio: 6, nombre: "ZONA OESTE" },
  { idBarrio: 3, nombre: "ZONA SUR" },
];

export const EditarEstaciones = () => {
  const { } = useSearchParams()
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();
  const [estacion, setEstacion] = useState()
  const { state } = useLocation()

  useEffect(() => {
    const getEstaciones = async () => {
      console.log(state.idEstacion)
      const estacion = await estacionesService.getEstacionById(state.idEstacion)
      setEstacion(estacion)
      console.log('state', state)
    }
    getEstaciones()
  }, [])

  const onSubmit = async (data) => {
    const estacion = {
      idEstacion: state.idEstacion,
      nombre: data.nombre,
      direccion: data.direccion,
      idBarrio: Number(data.idBarrio),
    }
    await estacionesService.putEstacion(estacion);
    navigate("/estaciones");
  };
  return (
    <div className="m-3">
      <h2>Crear Estacion</h2>
      {estacion && (
        <form onSubmit={handleSubmit(onSubmit)}>
          <div>
            <label htmlFor="nombre">nombre</label>
            <input type="text" {...register("nombre", { value: estacion.nombre })} />
          </div>
          <div>
            <label htmlFor="direccion">direccion</label>
            <input type="text" {...register("direccion", { value: estacion.direccion })} />
          </div>
          <div>
            <label htmlFor="barrio"></label>
            <select id='barrio' {...register("idBarrio", { value: estacion.idBarrio })}>
              {BARRIOS.map((barrio) => (
                <option key={barrio.idBarrio} value={barrio.idBarrio}>
                  {barrio.nombre}
                </option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary" type="submit">
            Guardar
          </button>
        </form>
      )}
    </div>
  );
};
