import { useEffect, useState } from "react";
import { set, useForm } from "react-hook-form";
import baseService from "../../../services/baseService"
import estacionesService from "./../../../services/estacionesService";
import barriosService from "../../../services/barriosService"
import { useNavigate } from "react-router-dom";

export const EstacionesTable = () => {
  const { register, handleSubmit } = useForm();
  const [estaciones, setEstaciones] = useState([]);
  const [barrios, setBarrios] = useState([])
  const navigate = useNavigate()

  useEffect(() => {
    const loggedUser = window.localStorage.getItem("alquileresLogedUser")
    if (loggedUser) {
      const { token } = JSON.parse(loggedUser)
      baseService.setToken(token)

      barriosService.getBarrios()
        .then((data) => setBarrios(data))

      estacionesService
        .getEstaciones()
        .then((data) => setEstaciones(data));
    }
  }, []);

  const borrar = async (idEstacion) => {
    try {
      await estacionesService.borrarEstacion(idEstacion);
      const data = await estacionesService.getEstaciones();
      setEstaciones(data)
      // estacionesService
      //   .getEstaciones()
      //   .then((data) => setEstaciones(data));
    }catch(err) {
      alert("Error al borrar:");
    } 
  }

  const modificar = (idEstacion) => {
      navigate(`/estaciones/editar`, {state: {idEstacion: idEstacion}})
  }

  const filterSubmit = async (data) => {
    try {
      const estacionesFiltradas = await estacionesService.getEstacionesFiltradas(data);
      setEstaciones(estacionesFiltradas);
    }
    catch (error) {
      console.error("Error fetching filtered estaciones:", error);
    }
  };

  return (
    <main className="container mt-3">
      <div>
        <form onSubmit={handleSubmit(filterSubmit)}>
          <div className="form-group mb-3">
            <label htmlFor="nombre" className="form-label">Nombre</label>
            <input type="text" id="nombre" name="nombre" className="form-control" {...register("nombre")} />
          </div>
          <div className="mb-3">
            <label htmlFor="direccion" className="form-label">Direccion: </label>
            <input
              type="text"
              name="direccion"
              id="direccion"
              className="form-control"
              {...register("direccion")}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="barrio" className="form-label">Barrio: </label>
            <select id="barrio" className="form-select" {...register("barrio")}>
              <option key="0" value="0">Todos</option>
              {barrios.map((barrio) => (
                <option key={barrio.idBarrio} value={barrio.idBarrio}>
                  {barrio.nombre}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <input className="form-check-input" type="checkbox" id="activo" {...register("activo")} />
            <label className="form-check-label" htmlFor="activo">&nbsp;Incluir resultados inactivos</label>
          </div>
          <div className="d-flex justify-content-end">
            <button type="submit" className="btn btn-primary">
              Filtrar
            </button>
          </div>
        </form>
      </div>
      <hr />
      <table className="table table-bordered">
        <thead className="table-secondary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Dirección</th>
            <th scope="col">Barrio</th>
            <th scope="col">Activo</th>
            <th scope="col">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {estaciones.map((estacion) => (
            <tr key={estacion.idEstacion}>
              <td>{estacion.idEstacion}</td>
              <td>{estacion.nombre}</td>
              <td>{estacion.direccion}</td>
              <td>{estacion.barrio.nombre}</td>
              <td>{estacion.activa == 1 ? "Si" : "No"}</td>
              <td>
                <button onClick={()=> modificar(estacion.idEstacion)}>Modificar</button>
                <button onClick={() => { borrar(estacion.idEstacion) }}>Borrar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
};
