import React from "react";
import { useForm } from "react-hook-form";
import estacionesService from "../../../services/estacionesService";
import {useNavigate, useSearchParams} from "react-router-dom"

const BARRIOS = [
  { idBarrio: 7, nombre: "CENTRO" },
  { idBarrio: 1, nombre: "CIUDAD UNIVERSITARIA" },
  { idBarrio: 2, nombre: "NUEVA CÓRDOBA" },
  { idBarrio: 19, nombre: "Nuevo Barrio" },
  { idBarrio: 20, nombre: "Nuevo Barrio" },
  { idBarrio: 21, nombre: "Nuevo Barrio" },
  { idBarrio: 4, nombre: "ZONA ESTE" },
  { idBarrio: 5, nombre: "ZONA NORTE" },
  { idBarrio: 6, nombre: "ZONA OESTE" },
  { idBarrio: 3, nombre: "ZONA SUR" },
];

export const CrearEstaciones = () => {
  const {} = useSearchParams()
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const onSubmit = (data) => {
    const estacion = {
        nombre: data.nombre,
        direccion: data.direccion,
        idBarrio: Number(data.idBarrio),
    }
    estacionesService.postEstacion(estacion);
    navigate("/estaciones");
  };
  return (
    <div className="m-3">
      <h2>Crear Estacion</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div>
          <label htmlFor="nombre">nombre</label>
          <input type="text" {...register("nombre")} />
        </div>
        <div>
          <label htmlFor="direccion">direccion</label>
          <input type="text" {...register("direccion")} />
        </div>
        <div>
          <label htmlFor="barrio"></label>
          <select id='barrio' {...register("idBarrio")}>
            {BARRIOS.map((barrio) => (
              <option key={barrio.idBarrio} value={barrio.idBarrio}>
                {barrio.nombre}
              </option>
            ))}
          </select>
        </div>
        <button className="btn btn-primary" type="submit">
          Crear estaciones
        </button>
      </form>
    </div>
  );
};
