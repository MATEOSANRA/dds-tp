import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export const Navbar = () => {
  const [user, setUser] = useState(null);

  // Verificar si existe el usuario en el localStorage
  const checkUser = () => {
    const userFromStorage = localStorage.getItem('alquileresLogedUser');
    if (userFromStorage) {
      setUser(JSON.parse(userFromStorage));
    }
  };

  // Llamar a checkUser al cargar el componente
  useEffect(() => {
    checkUser();
  }, []);

  // Handler para cerrar sesión
  const handleLogout = () => {
    localStorage.removeItem('alquileresLogedUser');
    setUser(null);
  };

  return (
    <nav className="bg-success navbar navbar-expand-lg sticky-top container-fluid">
      <div className="container-fluid">
        <Link to={'/'}>
          <div className="navbar-brand text-light">
            <i className="bi bi-bicycle logo-in-nav"> BiciAlquileres</i>
          </div>
        </Link>
        {user 
          ? (
        <div>
          <Link to={"/estaciones"} className="text-light">
            Estaciones
          </Link>
        </div> )
        : ('') }
        <div className="d-flex">
          <div className="flex-grow"></div>
          {user ? (
            <div id="usuarioLogeado" className="d-flex align-items-center position-relative">
              <div className="dropdown ml-2">
                <div
                  className="dropdown-toggle"
                  id="dropdownMenuButton"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                  style={{ cursor: 'pointer' }}
                >
                </div>
                  <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <li>
                      <button onClick={handleLogout} className="dropdown-item">
                        Cerrar sesión
                      </button>
                    </li>
                  </ul>
              </div>
              <i className="bi bi-person-fill text-light" style={{ marginRight: '8px' }}></i>
              <div className="text-light">{user.nombre}</div>
            </div>
          ) : (
            <div>
              <Link to={"/"} className="btn btn-primary">Iniciar sesión</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
