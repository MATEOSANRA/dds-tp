import axios from "axios";
import { baseUrl } from "./baseService";

const getBarrios = async () => {
  
  const response = await axios.get(`${baseUrl}/barrios`)
  return response.data

};

export default { getBarrios }