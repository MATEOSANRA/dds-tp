import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import { Navbar } from "./components/navbar/Navbar";
import { Inicio } from "./components/Inicio/Inicio";
import { ListaEstaciones } from "./components/ListaEstaciones/ListaEstaciones";
import { CrearEstaciones } from "./components/ListaEstaciones/CrearEstaciones/CrearEstaciones";
import { RegistroUsuario } from "./components/registro/RegistroUsuario";
import { EditarEstaciones } from "./components/ListaEstaciones/EditarEstaciones/EditarEstaciones";

function App() {
  return (
    <>
      <BrowserRouter>
      <Navbar/>
        <Routes>
          <Route path="/" element={<Inicio />} />
          <Route path="/estaciones" element={<ListaEstaciones />} />
          <Route path='/estaciones/crear' element={<CrearEstaciones/>}/>
          <Route path='/registro' element={<RegistroUsuario/>} />
          <Route path='/estaciones/editar' element={<EditarEstaciones/>} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
