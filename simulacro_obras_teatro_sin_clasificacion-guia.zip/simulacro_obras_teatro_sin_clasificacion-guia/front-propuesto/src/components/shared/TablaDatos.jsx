export default function TablaDatos({ items }) {
    return (
        <>
            <div className="card">
                <div className="card-body">
                    <table className="table table-responsive">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Titulo</th>
                                <th scope="col">Director</th>
                                <th scope="col">Precio Entrada</th>
                                <th scope="col">Fecha Desde</th>
                                <th scope="col">Fecha Hasta</th>
                            </tr>
                        </thead>
                        <tbody>
                            {items && items.map((item, index) => {
                                return (
                                    <>
                                        <tr key={item.Id}>
                                            <th scope="row">{item.Id}</th>
                                            <td>{item.Titulo}</td>
                                            <td>{item.Director}</td>
                                            <td>{item.PrecioEntrada}</td>
                                            <td>{item.FechaDesde}</td>
                                            <td>{item.FechaHasta}</td>
                                        </tr>
                                    </>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}